$(document).ready(function(){
   $('.myAccount').click(function(){       
       $('.accountDrop').slideToggle();
   })     
});

$(document).on("click", function (event) {
    var $trigger = $(".header");
    if ($trigger !== event.target && !$trigger.has(event.target).length) {
        $(".accountDrop").slideUp("fast");
    }
});

